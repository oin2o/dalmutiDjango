from django.apps import AppConfig


class DalmutiConfig(AppConfig):
    name = 'dalmuti'
